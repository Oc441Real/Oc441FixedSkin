<?php

/**
 * @name SkinBugWorkaround
 * @author alvin0319
 * @main alvin0319\SkinBugWorkaround\SkinBugWorkaround
 * @version 1.0.0
 * @api 4.0.0
 */

declare(strict_types=1);

namespace oc441\FixSkin;

use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\PlayerListPacket;
use pocketmine\network\mcpe\protocol\PlayerSkinPacket;
use pocketmine\plugin\PluginBase;

final class Main extends PluginBase{

	/** @var string[] */
	private array $capeIds = [];

	protected function onEnable() : void{
		$this->getServer()->getPluginManager()->registerEvent(DataPacketSendEvent::class, function(DataPacketSendEvent $event) : void{
			foreach($event->getTargets() as $session){
				foreach($event->getPackets() as $packet){
					if($packet instanceof PlayerSkinPacket){
						$player = $session->getPlayer();
						if($player !== null){
							$that = $this;
							(function() use ($that, $player) : void{
								/* @noinspection PhpUndefinedFieldInspection */
								$capeId = $this->capeId === "" && isset($that->capeIds[$player->getName()]) ? $that->capeIds[$player->getName()] : $this->capeId;
								$this->fullSkinId = $this->skinId . $capeId;
							})->call($packet->skin);
						}
					}elseif($packet instanceof PlayerListPacket){
						$player = $session->getPlayer();
						if($player !== null && $packet->type === PlayerListPacket::TYPE_ADD){
							foreach($packet->entries as $entry){
								$that = $this;
								if(isset($entry->username) && $entry->username === $player->getName()){
									(function() use ($that, $player) : void{
										/* @noinspection PhpUndefinedFieldInspection */
										$capeId = $this->capeId === "" && isset($that->capeIds[$player->getName()]) ? $that->capeIds[$player->getName()] : $this->capeId;
										$this->fullSkinId = $this->skinId . $capeId;
									})->call($entry->skinData);
								}
							}
						}
					}
				}
			}
		}, EventPriority::HIGHEST, $this);
		$this->getServer()->getPluginManager()->registerEvent(DataPacketReceiveEvent::class, function(DataPacketReceiveEvent $event) : void{
			$packet = $event->getPacket();
			$origin = $event->getOrigin();
			if($packet instanceof PlayerSkinPacket){
				$player = $origin->getPlayer();
				if($player !== null){
					$this->capeIds[$player->getName()] = $packet->skin->getCapeId();
				}
			}
		}, EventPriority::MONITOR, $this);
		$this->getServer()->getPluginManager()->registerEvent(PlayerQuitEvent::class, function(PlayerQuitEvent $event) : void{
			$player = $event->getPlayer();
			if(isset($this->capeIds[$player->getName()])){
				unset($this->capeIds[$player->getName()]);
			}
		}, EventPriority::NORMAL, $this);
	}
}